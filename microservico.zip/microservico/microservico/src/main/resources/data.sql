insert into user values(10, sysdate(), 'AB');
insert into user values(20, sysdate(), 'jill');
insert into user values(30, sysdate(), 'Jam');

insert into post values(10, 'Primeiro Post .', 10);
insert into post values(20, 'Segundo Post .', 10);
insert into post values(30, 'Terceiro Post .', 20);