package br.com.microservico.controllers;

import br.com.microservico.models.HelloWordBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.Locale;

@RestController
public class HelloWord {

    @Autowired
    private MessageSource messageSource;

    @RequestMapping(method = RequestMethod.GET, path = "/hello-word")
    public String HelloWord(){
        return "Hello - Word ...";
    }

    @RequestMapping(method = RequestMethod.GET, path = "/hello-word-bean")
    public HelloWordBean HelloWordBean(){
        return new HelloWordBean("mensagem do hello word bean.");
    }

    @RequestMapping(method = RequestMethod.GET, path = "/hello-word-bean/{nome}")
    public HelloWordBean HelloWordBeanPathVariable(@PathVariable String nome){
        return new HelloWordBean(String.format("Hello word %s", nome));
    }

    @RequestMapping(method = RequestMethod.GET, path = "/hello-word-internationalized")
    public String HelloWordInternationalized(){
        return messageSource.getMessage("good.morning.message", null, LocaleContextHolder.getLocale());
    }

}
