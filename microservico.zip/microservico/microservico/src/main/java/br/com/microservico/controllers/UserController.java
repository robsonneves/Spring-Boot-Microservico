package br.com.microservico.controllers;

import br.com.microservico.DAO.UserDao;
import br.com.microservico.entitys.User;
import br.com.microservico.exception.UserNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.Resource;
import org.springframework.hateoas.mvc.ControllerLinkBuilder;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import javax.validation.Valid;
import java.net.URI;
import java.util.List;

@RestController
public class UserController {

    @Autowired
    private UserDao service;

    @GetMapping("/users")
    public List<User> getAll(){
        return service.findAll();
    }

    @GetMapping("/users/{id}")
    public Resource<User> getById(@PathVariable int id){
        User user = service.findById(id);
        if(user == null)
            throw  new UserNotFoundException("id-"+id);

        Resource<User> resource = new Resource<User>(user);
        ControllerLinkBuilder linkTo = ControllerLinkBuilder.linkTo(ControllerLinkBuilder.methodOn(this.getClass()).getAll());
        resource.add(linkTo.withRel("all-users"));
        return resource;
    }

    @PostMapping("/users")
    public ResponseEntity<Object> createUser(@Valid @RequestBody User user){
        User savedUser = service.save(user);
        URI location = ServletUriComponentsBuilder
                .fromCurrentRequest()
                .path("/{id}")
                .buildAndExpand(savedUser.getId())
                .toUri();
        return ResponseEntity.created(location).build();
    }

    @DeleteMapping("/users/{id}")
    public User deleteById(@PathVariable int id){
        User user = service.deleteById(id);
        if(user == null)
            throw  new UserNotFoundException("id-"+id);
        return user;
    }

}
