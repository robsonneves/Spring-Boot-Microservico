package br.com.microservico.controllers;

import br.com.microservico.models.SameBean;
import com.fasterxml.jackson.databind.ser.FilterProvider;
import com.fasterxml.jackson.databind.ser.impl.SimpleBeanPropertyFilter;
import com.fasterxml.jackson.databind.ser.impl.SimpleFilterProvider;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Arrays;
import java.util.List;

@RestController
public class FilterController {

    @GetMapping(path = "/filter")
    public MappingJacksonValue finAll(){
        //return new SameBean("Filter 1", "Filter 2", "Filter 3");

        SameBean sameBean = new SameBean("value 1", "value 2", "value 3");
        SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("field1", "field2");
        FilterProvider filters = new SimpleFilterProvider().addFilter("SameBeanFilter", filter);
        MappingJacksonValue mapping = new MappingJacksonValue(sameBean);
        mapping.setFilters(filters);
        return mapping;

    }

    @GetMapping(path = "/filter-list")
    public List<SameBean> finAllList(){
        return Arrays.asList(
            new SameBean("Filter 1", "Filter 2", "Filter 3"),
            new SameBean("Filter 12", "Filter 22", "Filter 32")
        );
    }

}
