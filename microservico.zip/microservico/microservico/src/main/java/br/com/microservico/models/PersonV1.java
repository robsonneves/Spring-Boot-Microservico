package br.com.microservico.models;

public class PersonV1 {
    private String nome;

    public PersonV1(String bob_chalie) {
        super();
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

}
