package br.com.microservico.models;

public class HelloWordBean {

    private final String mensagem;

    public HelloWordBean(String mensagem) {
        this.mensagem = mensagem;
    }

    public String getMensagem() {
        return mensagem;
    }

}
