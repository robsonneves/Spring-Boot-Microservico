package br.com.microservico.models;

public class PersonV2 {
    private Name name;

    public PersonV2(Name name) {
        super();
    }

    public Name getName() {
        return name;
    }

    public void setName(Name name) {
        this.name = name;
    }

}
