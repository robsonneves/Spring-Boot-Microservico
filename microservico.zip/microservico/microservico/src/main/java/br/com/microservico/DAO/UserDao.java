package br.com.microservico.DAO;

import br.com.microservico.entitys.User;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@Component
public class UserDao {

    private static List<User> users = new ArrayList<>();

    private static int usersCount = 3;

    /*
    static {
        users.add(new User(1, "Adam", new Date()));
        users.add(new User(2, "Eve", new Date()));
        users.add(new User(3, "Jack", new Date()));
    }

     */

    public List<User> findAll(){
        return users;
    }

    public User save(User user){
        user.setId(++usersCount);
        users.add(user);
        return user;
    }

    public User findById(int id){
        for(User user : users){
            if(user.getId() == id){
                return user;
            }
        }
        return null;
    }

    public User deleteById(int id){
        Iterator<User> itarator = users.iterator();
        while (itarator.hasNext()) {
            User user = itarator.next();
            if(user.getId() == id){
                itarator.remove();
                return user;
            }
        }
        return null;
    }

}
