package br.com.microservico;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroservicoApplicationTests {

	@Test
	void contextLoads() {
	}

}
