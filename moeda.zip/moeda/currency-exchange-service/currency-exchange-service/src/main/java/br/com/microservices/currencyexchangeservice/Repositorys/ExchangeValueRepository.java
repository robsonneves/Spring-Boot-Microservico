package br.com.microservices.currencyexchangeservice.Repositorys;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.microservices.currencyexchangeservice.entitys.ExchangeValue;

public interface ExchangeValueRepository extends JpaRepository<ExchangeValue, Long> {
	ExchangeValue findByFromAndTo(String from, String to);
}
