package br.com.microservices.currencyconversionservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CurrencyConversionServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
